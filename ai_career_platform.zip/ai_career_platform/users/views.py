from rest_framework import generics, permissions
from rest_framework_simplejwt.views import TokenObtainPairView
from .models import CustomUser, Profile
from .serializers import RegisterSerializer, UserSerializer, ProfileSerializer

class RegisterView(generics.CreateAPIView):
    """
    POST /api/auth/register/
    Registers a new user. Uses RegisterSerializer to validate data.
    """
    queryset = CustomUser.objects.all()
    permission_classes = (permissions.AllowAny,)
    serializer_class = RegisterSerializer


class ProfileView(generics.RetrieveUpdateAPIView):
    """
    GET /api/profile/       → returns current user's Profile
    PUT /api/profile/       → update profile fields
    """
    queryset = Profile.objects.all()
    serializer_class = ProfileSerializer
    permission_classes = (permissions.IsAuthenticated,)

    def get_object(self):
        # Return the Profile instance of the currently authenticated user
        return self.request.user.profile
