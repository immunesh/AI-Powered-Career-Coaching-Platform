from django.urls import path
from rest_framework_simplejwt.views import TokenObtainPairView, TokenRefreshView
from .views import RegisterView, ProfileView

urlpatterns = [
    # Registration endpoint
    path('auth/register/', RegisterView.as_view(), name='register'),

    # JWT login/refresh endpoints
    path('auth/login/', TokenObtainPairView.as_view(), name='token_obtain_pair'),
    path('auth/token/refresh/', TokenRefreshView.as_view(), name='token_refresh'),

    # Profile retrieval/update
    path('profile/', ProfileView.as_view(), name='profile'),
]
