from rest_framework import serializers
from django.contrib.auth.password_validation import validate_password
from .models import CustomUser, Profile

class UserSerializer(serializers.ModelSerializer):
    """
    Serializer for reading user data (no passwords).
    """
    class Meta:
        model = CustomUser
        fields = ['id', 'username', 'email', 'is_student', 'is_professional']


class RegisterSerializer(serializers.ModelSerializer):
    """
    Serializer for user registration. 
    Enforces that password and password2 match, and applies Django's password validators.
    """
    password = serializers.CharField(write_only=True, required=True, validators=[validate_password])
    password2 = serializers.CharField(write_only=True, required=True)  # confirmation

    class Meta:
        model = CustomUser
        fields = ['username', 'email', 'password', 'password2', 'is_student', 'is_professional']

    def validate(self, attrs):
        if attrs['password'] != attrs['password2']:
            raise serializers.ValidationError({"password": "Passwords must match."})
        return attrs

    def create(self, validated_data):
        # Pop out password2 (we only need one copy)
        validated_data.pop('password2')
        user = CustomUser.objects.create(
            username=validated_data['username'],
            email=validated_data['email'],
            is_student=validated_data.get('is_student', False),
            is_professional=validated_data.get('is_professional', False)
        )
        user.set_password(validated_data['password'])
        user.save()
        return user


class ProfileSerializer(serializers.ModelSerializer):
    """
    Serializer for Profile. Read/write all fields except the user FK (which is read-only).
    """
    user = UserSerializer(read_only=True)

    class Meta:
        model = Profile
        fields = ['user', 'bio', 'location', 'skills', 'education', 'experience']
