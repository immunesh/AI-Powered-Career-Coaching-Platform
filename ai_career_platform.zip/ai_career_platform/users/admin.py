from django.contrib import admin
from django.contrib.auth.admin import UserAdmin
from .models import CustomUser, Profile

@admin.register(CustomUser)
class CustomUserAdmin(UserAdmin):
    """
    Register CustomUser so you can manage users in the Django admin.
    """
    model = CustomUser
    list_display = ['username', 'email', 'is_student', 'is_professional', 'is_staff']
    fieldsets = UserAdmin.fieldsets + (
        (None, {'fields': ('is_student', 'is_professional')}),
    )

@admin.register(Profile)
class ProfileAdmin(admin.ModelAdmin):
    """
    Register Profile for admin view/editing.
    """
    model = Profile
    list_display = ['user', 'location', 'skills']
