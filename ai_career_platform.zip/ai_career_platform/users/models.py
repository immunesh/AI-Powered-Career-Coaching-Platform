from django.contrib.auth.models import AbstractUser
from django.db import models

class CustomUser(AbstractUser):
    """
    Extends Django's AbstractUser to add extra flags:
    - email is unique
    - identify if user is a student or professional
    """
    email = models.EmailField(unique=True)
    is_student = models.BooleanField(default=False)
    is_professional = models.BooleanField(default=False)

    def __str__(self):
        return self.username


class Profile(models.Model):
    """
    One-to-one Profile for each CustomUser,
    storing additional info like bio, skills, education, etc.
    """
    user = models.OneToOneField(CustomUser, on_delete=models.CASCADE)
    bio = models.TextField(blank=True)
    location = models.CharField(max_length=100, blank=True)
    skills = models.TextField(blank=True)
    education = models.TextField(blank=True)
    experience = models.TextField(blank=True)

    def __str__(self):
        return f"{self.user.username}'s Profile"
